module com.cartes.benjamin {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;

    opens com.cartes.benjamin to javafx.fxml;
    exports com.cartes.benjamin;
    exports com.cartes.benjamin.model;
    opens com.cartes.benjamin.model to javafx.fxml;
    exports com.cartes.benjamin.controller;
    opens com.cartes.benjamin.controller to javafx.fxml;
}