package com.cartes.benjamin.model;

import com.cartes.benjamin.dto.UsuarioDto;

import java.util.ArrayList;

public class UsuariosModel {
}

